package com.example.learn2grow.repository;

import com.example.learn2grow.entity.RespuestasEstudiante;
import org.springframework.data.repository.CrudRepository;

public interface RespuestasEstudianteCrudRepository extends CrudRepository<RespuestasEstudiante, Long> {

}