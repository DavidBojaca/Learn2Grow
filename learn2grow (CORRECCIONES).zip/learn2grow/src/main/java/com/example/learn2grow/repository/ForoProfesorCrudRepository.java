package com.example.learn2grow.repository;

import com.example.learn2grow.entity.ForoProfesor;
import org.springframework.data.repository.CrudRepository;

public interface ForoProfesorCrudRepository extends CrudRepository<ForoProfesor, Long> {

}
