package com.example.learn2grow.repository;

import com.example.learn2grow.entity.ForoEstudiante;
import org.springframework.data.repository.CrudRepository;

public interface ForoEstudianteCrudRepository extends CrudRepository<ForoEstudiante, Long> {

}