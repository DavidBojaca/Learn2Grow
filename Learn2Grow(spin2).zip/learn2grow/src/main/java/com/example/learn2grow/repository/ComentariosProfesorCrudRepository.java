package com.example.learn2grow.repository;

import com.example.learn2grow.entity.ComentariosProfesor;
import org.springframework.data.repository.CrudRepository;

public interface ComentariosProfesorCrudRepository extends CrudRepository<ComentariosProfesor, Long> {

}
