package com.example.learn2grow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Learn2growApplication {

    public static void main(String[] args) {
        SpringApplication.run(Learn2growApplication.class, args);
    }

}
