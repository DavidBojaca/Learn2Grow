package com.example.learn2grow.repository;

import com.example.learn2grow.entity.ComentariosEstudiante;
import org.springframework.data.repository.CrudRepository;

public interface ComentariosEstudianteCrudRepository extends CrudRepository<ComentariosEstudiante, Long> {
}